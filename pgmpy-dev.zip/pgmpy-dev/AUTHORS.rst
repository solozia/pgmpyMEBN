People
------
   
Organisation Admins
===================

* Ankur Ankan <ankurankan@gmail.com>

* Abinash Panda <mailme.abinashpanda@gmail.com>

Contributors
============

(in order of the date of their first contribution made)

* Ankur Ankan <ankurankan@gmail.com>

* Shikhar Nigam <snigam3112@gmail.com>

* Abinash Panda <mailme.abinashpanda@gmail.com>

* William Lyon <wlyon@quantpost.com>

* Navin Chandak <navinchandak92@gmail.com>

* Jaspreet Singh <jaspreetsingh112@gmail.com>

* Neha Soni <neha.soni.ece10@itbhu.ac.in>

* Jaidev Deshpande <deshpande.jaidev@gmail.com>

* Abhijeet Kislay <abhijeetkislay@gmail.com>

* Palash Ahuja <abhor902@gmail.com>

* Saket Choudhary <saketkc@gmail.com>

* all3fox <all3fox@gmail.com>

* Vivek Jain <vivek425ster@gmail.com>

* Ashwini Chaudhary <monty.sinngh@gmail.com>

* Sitesh Ranjan <siteshjaiswal@gmail.com>

* Pratyaksh Sharma <pratyaksh@me.com>

* Aleksandar Dimitriev <dimitriev_a@yahoo.com>

* Demyanov <artyom.demyanov96@gmail.com>

* Yashu Seth <yashuseth2503@gmail.com>

* Utkarsh Gupta <utkarsh.gupta550@gmail.com>

* Kshitij Saraogi <KshitijSaraogi@gmail.com>

* joncrall <erotemic@gmail.com>

* elkbrsathuji <elkana.baris@mail.huji.ac.il>
